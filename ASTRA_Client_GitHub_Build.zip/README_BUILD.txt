ASTRA Client starter

GitHub Actions workflow is included at .github/workflows/android-apk.yml.
A Gradle Wrapper is required to build automatically: gradlew, gradlew.bat,
and gradle/wrapper/gradle-wrapper.jar + gradle-wrapper.properties.
Generate it from Android Studio/Gradle with:
gradle wrapper --gradle-version 8.7
Then commit wrapper files to the repository.
